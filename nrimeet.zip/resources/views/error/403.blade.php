@extends('layouts.app')
<style type="text/css">
	.timeline-date{width: 200px !important;}
</style>
@section('content')
<div class="nk-content-inner">
	<div class="nk-content-body">
        <h4 style="text-align: center;">You do not have permission to access this resource.</h4>
	</div>
</div>
<!-- Mopdal Small -->
@endsection