

<?php $__env->startSection('content'); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><a href="javascript:history.back()" class="pt-3"><em
                            class="icon ni ni-chevron-left back-icon"></em> </a>Add Bulk Booking</h3>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <form role="form" method="post" action="<?php echo e(url('admin/bulk-bookings/store')); ?>">
        <?php echo csrf_field(); ?>
        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Room <br> Information</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Name','for' => 'name','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Name','for' => 'name','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'name','icon' => 'mail','required' => 'true','class' => 'readonlyinput','placeholder' => 'Select','name' => 'name','value' => ''.e(isset($bulkBooking) ? $bulkBooking->name : old('name')).'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                      
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Hotel','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Hotel','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select','name' => 'hotel','id' => 'hotel']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select','name' => 'hotel','id' => 'hotel']); ?>
                                        <option>Select</option>
                                        <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                        <?php if(isset($bulkBooking) && $bulkBooking->hotel_id == $hotel->id): ?>
                                        selected
                                        <?php elseif(old('hotel') == $hotel->id): ?> 
                                        selected
                                        <?php endif; ?>
                                        value="<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Room Type','for' => 'roomType','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Room Type','for' => 'roomType','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'roomType','icon' => 'mail','required' => 'true','class' => 'roomType','placeholder' => 'Select','name' => 'roomType']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'roomType','icon' => 'mail','required' => 'true','class' => 'roomType','placeholder' => 'Select','name' => 'roomType']); ?>
                                        <option>Select</option>
                                        <?php if(isset($bulkBooking)): ?>
                                        <?php $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rooms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option
                                        <?php if(isset($bulkBooking) && $bulkBooking->room_type_id == $rooms->id): ?>
                                        selected
                                        <?php elseif(old('roomType') == $rooms->id): ?> 
                                        selected
                                        <?php endif; ?>
                                        value="<?php echo e($rooms->id); ?>"><?php echo e($rooms->room_type_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Booking From','for' => 'bookingFrom','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Booking From','for' => 'bookingFrom','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'bookingFrom','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Guest','name' => 'bookingFrom']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'bookingFrom','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Guest','name' => 'bookingFrom']); ?>
                                        <option >Select</option>
                                        <option 
                                        <?php if(isset($bulkBooking) && $bulkBooking->booking_person == 'MP Tourism'): ?>
                                        selected
                                        <?php elseif(old('bookingFrom') == 'MP Tourism'): ?> 
                                        selected
                                        <?php endif; ?>>MP Tourism</option>
                                        <option <?php if(isset($bulkBooking) && $bulkBooking->booking_person == 'MP GOVT'): ?>
                                        selected
                                        <?php elseif(old('bookingFrom') == 'MP GOVT'): ?> 
                                        selected
                                        <?php endif; ?>>MP GOVT</option>
                                        <option <?php if(isset($bulkBooking) && $bulkBooking->booking_person == 'YPBD'): ?>
                                        selected
                                        <?php elseif(old('bookingFrom') == 'YPBD'): ?> 
                                        selected
                                        <?php endif; ?>>YPBD</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Select check IN and Check out Date','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Select check IN and Check out Date','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(isset($bulkBooking) ? $bulkBooking->checkin_date : old('checkin_date')).'','for' => 'checkin_date','class' => 'date-picker checkDate','icon' => 'calender-date-fill','required' => 'true','placeholder' => 'Date of birth','name' => 'checkin_date']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(isset($bulkBooking) ? $bulkBooking->checkout_date : old('checkout_date')).'','for' => 'checkout_date','class' => 'date-picker checkDate','icon' => 'calender-date-fill','required' => 'true','placeholder' => 'Date of birth','name' => 'checkout_date']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => '#Rooms','for' => 'rooms','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => '#Rooms','for' => 'rooms','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'rooms','icon' => 'building','required' => 'true','class' => 'rooms','placeholder' => '#Rooms','name' => 'rooms','value' => ''.e(isset($bulkBooking) ? $bulkBooking->room_count : old('rooms')).'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['max' => ''.e(isset($availableRooms) ? $availableRooms->count : '').'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                      
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <?php if(isset($bulkBooking)): ?>
        <input type="hidden" name="bulkBookingId" id="bulkBookingId" value="<?php echo e($bulkBooking->id); ?>">
        
        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Rooms <br> Booking Details</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">
                            <?php for($i = 0; $i < $bulkBooking->room_count; $i++): ?>
                            <div class="row g-3 align-center">
                                <div class="col-md-4">
                                    
                                </div>
                                <div class="col-lg-8">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Booking Id','for' => 'name','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Booking Id','for' => 'name','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Adult Count','for' => 'name','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Adult Count','for' => 'name','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                            
                                        </div>
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Child Count','for' => 'name','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Child Count','for' => 'name','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-md-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Room '.e($i+1).'','for' => 'name','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Room '.e($i+1).'','for' => 'name','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <div class="row g-3">
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'bookingId','icon' => 'building-fill','required' => 'true','placeholder' => 'Booking Id','name' => 'bookingId[]','value' => ''.e(isset($bulkBooking) ? $bulkBookingRooms[$i]['booking_id'] : '').'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'adultCount','icon' => 'users-fill','required' => 'true','placeholder' => 'Adult count','name' => 'adultCount[]','value' => ''.e(isset($bulkBooking) ? $bulkBookingRooms[$i]['adult_count'] : '').'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-md-4">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'childCount','icon' => 'users-fill','required' => 'true','placeholder' => 'Child count','name' => 'childCount[]','value' => ''.e(isset($bulkBooking) ? $bulkBookingRooms[$i]['child_count'] : '').'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endfor; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->
        <?php endif; ?>
        <div class="nk-block">
            <div class="row">
                <div class="col-md-12">
                    <div class="sp-plan-info pt-0 pb-0 card-inner">
                        <div class="row">
                            <div class="col-lg-7 text-right offset-lg-5">
                                <div class="form-group">
                                    <a href="javascript:history.back()" class="btn btn-outline-light">Cancel</a>
                                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, []); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn btn-primary']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div><!-- .sp-plan-info -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div>
    </form>


    <script type="text/javascript">
        $(document).ready(function() {

            <?php if(isset($bulkBooking)): ?>
            $('.readonlyinput').attr("readonly", true);
            <?php endif; ?>
          
            $('#hotel').change(function(){
                var root_url = "<?php echo Request::root(); ?>";
                    $.ajax({
                        url: root_url + '/admin/hotel/hotel-rooms/'+$(this).val(),
                        data: {
                            
                        },
                        //dataType: "html",
                        method: "GET",
                        cache: false,
                        success: function (response) {
                            if(response.success){


                                $('.roomType')
                                    .find('option')
                                    .remove()
                                    .end()
                                    .append('<option value="">Select Room</option>');

                                $.each(response.hotelRooms, function(key, room) {   
                                     $('.roomType')
                                         .append($("<option></option>")
                                                    .attr("value", room.id)
                                                    .attr("data-roomData", JSON.stringify(room))
                                                    .text(room.room_type_name)); 
                                });

                            }
                        }
                    });
            });

            $('.roomType').change(function(){
                var root_url = "<?php echo Request::root(); ?>";
                $.ajax({
                    url: root_url + '/admin/bulk-bookings/hotel-rooms/'+$(this).val(),
                    data: {
                        
                    },
                    //dataType: "html",
                    method: "GET",
                    cache: false,
                    success: function (response) {
                        console.log(response.hotelRooms.count);
                        if(response.success){
                            $('.rooms').attr('max',response.hotelRooms.count);
                        }
                    }
                });
            });

        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Hotel\Resources/views/bulkBooking/bulkBooking.blade.php ENDPATH**/ ?>