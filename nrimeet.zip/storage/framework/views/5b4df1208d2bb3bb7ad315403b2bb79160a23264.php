

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="pb-35">
        <div class="marquee">
            <marquee width="100%" direction="left" height="100px">
                Dear PBD Delegates, Govt of M.P. has revised the rates of hotel accommodation. Delegates who have booked the
                accommodation before 21/11/2022 16:00 hours IST, any excess amount charged will be refunded to their
                respective bank account with-in 15 working days.
            </marquee>
        </div>
    </div>
    <div class="container">
        <div class="shb-booking-page-wrapper shb-clearfix">
            <div class="shb-booking-page-main full-width">
                <form action="<?php echo e(url('razorpay-payment')); ?>" method="POST" id="billing_form">
                    <!-- Billing Details -->
                    <?php echo csrf_field(); ?>
                    
                    <input type="hidden" name="bookingData" value="<?php echo e(json_encode($bookingData)); ?>">
                    <input type="hidden" name="billingData" value="<?php echo e(json_encode($data)); ?>">

                    <div class="razorpay-script"></div>

                    <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="<?php echo e(config('constants.RAZORPAY_KEY')); ?>" 
                        data-amount="<?php echo e($bookingData['amount']); ?>" data-buttontext="" data-name="NRI MEET" data-description="PBD NRI MEET"
                        data-image="https://www.itsolutionstuff.com/frontTheme/images/logo.png" data-prefill.name="name"
                        data-prefill.email="email" data-theme.color="#ff7529"></script>
                    <input type="submit" value="Pay <?php echo e($bookingData['amount']); ?> INR" class="primary-button razorpay-payment-button">
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<?php $__env->stopSection(); ?>
<?php $__env->startPush('footerScripts'); ?>
<script src="<?php echo e(url('js/address.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready(function() {
        $('.razorpay-payment-button').trigger('click');
    });
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Frontend\Resources/views/razorpay_form.blade.php ENDPATH**/ ?>