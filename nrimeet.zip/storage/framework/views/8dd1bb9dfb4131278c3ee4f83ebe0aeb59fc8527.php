<button <?php echo e($attributes); ?> <?php echo e($attributes->merge(['class' => 'btn btn-'.$size.' btn-'.$buttonType.' '. $className ])); ?>>
    <?php if($icon != null): ?>
    <em class="icon ni ni-<?php echo e($icon); ?>"></em>
    <?php endif; ?>
    <span><?php echo e($slot); ?></span>
</button><?php /**PATH C:\xampp\htdocs\nrimeet\resources\views/components/inputs/button.blade.php ENDPATH**/ ?>