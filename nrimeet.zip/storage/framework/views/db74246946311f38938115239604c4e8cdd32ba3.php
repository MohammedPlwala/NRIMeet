

<?php $__env->startSection('content'); ?>
  <!-- Page Header -->
  <div class="page-header">
    <h1>Contact Us</h1>
  </div>
  <div class="container">
    <h3 class="sohohotel-title-20px sohohotel-clearfix sohohotel-title-left">Contact Details</h3>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Frontend\Resources/views/contactUs.blade.php ENDPATH**/ ?>