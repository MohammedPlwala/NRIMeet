<?php $__env->startSection('content'); ?>
    <h1>Hello Worlds</h1>

    <p>
        This view is loaded from module: Dashboard
    </p>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Dashboard\Resources/views/index.blade.php ENDPATH**/ ?>