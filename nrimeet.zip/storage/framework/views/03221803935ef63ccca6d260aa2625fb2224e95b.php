

<?php $__env->startSection('content'); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><a href="javascript:history.back()" class="pt-3"><em class="icon ni ni-chevron-left back-icon"></em> </a> <?php if(isset($room)): ?> Edit <?php else: ?> Add <?php endif; ?> Room</h3>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <form role="form" method="post" action="<?php echo e(url('admin/hotel/rooms/add')); ?>" enctype="multipart/form-data"  >
        <?php echo csrf_field(); ?>
     
        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Room <br> Information</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">
                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Hotel Name','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Hotel Name','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel','name' => 'hotel']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel','name' => 'hotel']); ?>
                                        <option>Select Hotel</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option 
                                            <?php if(isset($room) && $room->hotel_id == $hotel->id): ?> selected  <?php endif; ?>
                                            value="<?php echo e($hotel->id); ?>"><?php echo e(ucfirst($hotel->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Room Type','for' => '','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Room Type','for' => '','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'room_type','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'room_type']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'room_type','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'room_type']); ?>
                                        <option>Select Room Type</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $roomTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option 
                                            <?php if(isset($room) && $room->type_id == $roomType->id): ?> selected  <?php endif; ?>
                                            value="<?php echo e($roomType->id); ?>"><?php echo e(ucfirst($roomType->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Room Name','for' => 'email','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Room Name','for' => 'email','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php
                                        $value = "";
                                        if(isset($room)){
                                            $value = $room->name;
                                        }
                                    ?>
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['for' => 'room_name','icon' => 'umbrela','required' => 'true','class' => '','name' => 'room_name','value' => ''.e($value).'']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => 'Email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                    <?php if($errors->has('room_name')): ?>
                                        <span class="text-danger custom-error-text"><?php echo e($errors->first('room_name')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Rate','for' => 'email','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Rate','for' => 'email','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php
                                        $value = "";
                                        if(isset($room)){
                                            $value = $room->rate;
                                        }
                                    ?>
                                    <?php if (isset($component)) { $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Number::class, ['value' => ''.e($value).'','for' => 'rate','icon' => 'sign-inr','required' => 'true','class' => '','name' => 'rate']); ?>
<?php $component->withName('inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => 'Email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67)): ?>
<?php $component = $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67; ?>
<?php unset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67); ?>
<?php endif; ?>
                                    <?php if($errors->has('rate')): ?>
                                        <span class="text-danger custom-error-text"><?php echo e($errors->first('rate')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Extra Bed Available','for' => '','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Extra Bed Available','for' => '','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'extra_bed_available','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'extra_bed_available']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'extra_bed_available','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'extra_bed_available']); ?>
                                        <option 
                                        <?php if(isset($room) && $room->extra_bed_available == 0): ?> selected  <?php endif; ?>
                                        value="0">No</option>
                                        <option 
                                        <?php if(isset($room) && $room->extra_bed_available == 1): ?> selected  <?php endif; ?>
                                        value="1">Yes</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Extra Bed Rate','for' => 'email','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Extra Bed Rate','for' => 'email','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php
                                        $value = "";
                                        if(isset($room)){
                                            $value = $room->extra_bed_rate;
                                        }
                                    ?>
                                    <?php if (isset($component)) { $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Number::class, ['value' => ''.e($value).'','for' => 'extra_bed_rate','icon' => 'sign-inr','required' => 'true','class' => '','name' => 'extra_bed_rate']); ?>
<?php $component->withName('inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => 'Email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67)): ?>
<?php $component = $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67; ?>
<?php unset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67); ?>
<?php endif; ?>
                                    <?php if($errors->has('extra_bed_rate')): ?>
                                        <span class="text-danger custom-error-text"><?php echo e($errors->first('extra_bed_rate')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Allocated Rooms','for' => 'email','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Allocated Rooms','for' => 'email','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php
                                        $value = "";
                                        if(isset($room)){
                                            $value = $room->allocated_rooms;
                                        }
                                    ?>
                                    <?php if (isset($component)) { $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Number::class, ['for' => 'allocated_rooms','icon' => 'home-alt','required' => 'true','class' => '','name' => 'allocated_rooms','value' => ''.e($value).'']); ?>
<?php $component->withName('inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => '0']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67)): ?>
<?php $component = $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67; ?>
<?php unset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67); ?>
<?php endif; ?>
                                    <?php if($errors->has('allocated_rooms')): ?>
                                        <span class="text-danger custom-error-text"><?php echo e($errors->first('allocated_rooms')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'MPT Reserve','for' => 'email','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'MPT Reserve','for' => 'email','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php
                                        $value = "";
                                        if(isset($room)){
                                            $value = $room->mpt_reserve;
                                        }
                                    ?>
                                    <?php if (isset($component)) { $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Number::class, ['value' => ''.e($value).'','for' => 'mpt_reserve','icon' => 'umbrela','required' => 'true','class' => '','name' => 'mpt_reserve']); ?>
<?php $component->withName('inputs.number'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['placeholder' => 'Email']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67)): ?>
<?php $component = $__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67; ?>
<?php unset($__componentOriginal3fa99016d69f43334d8833edc2e2c75a67c9aa67); ?>
<?php endif; ?>
                                    <?php if($errors->has('mpt_reserve')): ?>
                                        <span class="text-danger custom-error-text"><?php echo e($errors->first('mpt_reserve')); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Available Rooms','for' => 'email','suggestion' => '.','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Available Rooms','for' => 'email','suggestion' => '.','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                   <?php
                                        $value = 0;
                                        if(isset($room)){
                                            $value = $room->count;
                                        }
                                    ?>
                                    <?php echo e($value); ?>

                                </div>
                            </div>

                            <?php if(isset($room)): ?> 
                            <input type="hidden" name="room_id" value="<?php echo e($room->id); ?>">
                            <?php endif; ?>

                            <div class="row g-3 align-center">
                                <div class="col-lg-5">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Status','for' => '','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Status','for' => '','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-7">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'status','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'status']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'status','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel Type','name' => 'status']); ?>
                                        <option 
                                        <?php if(isset($room) && $room->status == 'active'): ?> selected  <?php endif; ?>
                                        value="active">Active</option>
                                        <option 
                                        <?php if(isset($room) && $room->status == 'inactive'): ?> selected  <?php endif; ?>
                                        value="inactive">Inactive</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->
       
        
        <div class="nk-block">
            <?php if(isset($user)): ?>
                <input type="hidden" name="userId" id="userId" value="<?php echo e($user->id); ?>">
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="sp-plan-info pt-0 pb-0 card-inner">  
                            <div class="row">
                                <div class="col-lg-7 text-right offset-lg-5">
                                    <div class="form-group">
                                        <a href="javascript:history.back()" class="btn btn-outline-light">Cancel</a>
                                        <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, []); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn btn-primary']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                                    </div>
                                </div>
                            </div>
                    </div><!-- .sp-plan-info -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Hotel\Resources/views/roomUpdate.blade.php ENDPATH**/ ?>