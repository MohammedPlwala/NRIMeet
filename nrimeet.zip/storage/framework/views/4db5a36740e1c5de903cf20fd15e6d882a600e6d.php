<?php $attributes = $attributes->exceptProps([
    'for' => '',
    'label' => '',
    'value' => '',
    'placeholder' => '',
    'id' => '',
    'name' => '',
    'required' =>'false',
    'formNote' => 'Note: Maximum character limit is 500 for description.',
    'maxlength'=>'2000',
    'minlength'=>'0'
]); ?>
<?php foreach (array_filter(([
    'for' => '',
    'label' => '',
    'value' => '',
    'placeholder' => '',
    'id' => '',
    'name' => '',
    'required' =>'false',
    'formNote' => 'Note: Maximum character limit is 500 for description.',
    'maxlength'=>'2000',
    'minlength'=>'0'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group">
    <?php if($label != ''): ?>
        <label class="form-label" for="<?php echo e($for); ?>"><?php echo e($label); ?><?php if($required != '' && $required == 'true' ): ?><span class="text-danger">*</span><?php endif; ?></label>
    <?php endif; ?>
    <div class="form-control-wrap">
        <textarea class="form-control" <?php if($required != '' && $required == 'true' ): ?> required="<?php echo e($required); ?>" <?php endif; ?> id="<?php echo e($for); ?>" minlength="<?php echo e($minlength); ?>" maxlength="<?php echo e($maxlength); ?>"  placeholder="<?php echo e($placeholder); ?>" name="<?php echo e($name); ?>" data-parsley-errors-container=".parsley-container-<?php echo e($name); ?>"><?php echo e($value); ?></textarea>
    </div>
    <?php if(isset($formNote) && $formNote != ''): ?>
            <span class="form-note mt-0"><?php echo e($formNote); ?></span>
    <?php endif; ?>
    <div class="parsley-container-<?php echo e($name); ?>"></div>
</div><?php /**PATH C:\xampp\htdocs\nrimeet\resources\views/components/inputs/textarea.blade.php ENDPATH**/ ?>