

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <div class="pb-35">
        <div class="marquee">
            <marquee width="100%" direction="left" height="100px">
                Dear PBD Delegates, Govt of M.P. has revised the rates of hotel accommodation. Delegates who have booked the
                accommodation before 21/11/2022 16:00 hours IST, any excess amount charged will be refunded to their
                respective bank account with-in 15 working days.
            </marquee>
        </div>
    </div>

    <div class="container">
        <div class="shb-booking-page-wrapper shb-clearfix">
            <div class="shb-booking-page-main full-width">
                <div class="shb-booking-step-wrapper shb-clearfix">
                    <div class="shb-booking-step shb-booking-step-current"><a href="<?php echo e(url('/search')); ?>">1</a><a href="<?php echo e(url('/search')); ?>">Rooms</a></div>
                    <div class="shb-booking-step shb-booking-step-current"><a href="javascript:void(0)">2</a><a href="javascript:void(0)">Booking Summary</a></div>
                    <div class="shb-booking-step "><a href="javascript:void(0)">3</a><a href="javascript:void(0)">Payment</a></div>
                    <div class="shb-booking-step "><a href="javascript:void(0)">4</a><a href="javascript:void(0)">Complete</a></div>
                    <div class="shb-booking-step-line">
                        <div style="width:33%;"></div>
                    </div>
                </div>
                <div class="shb-booking-page-sidebar full-width">
                    <!-- BEGIN .shb-booking-your-stay-wrapper -->
                    <div class="shb-booking-your-stay-wrapper">
                        <!-- BEGIN .shb-booking-your-stay-items-wrapper -->
                        <div class="shb-booking-your-stay-items-wrapper">
                        
                            <!-- BEGIN .shb-booking-your-stay-item-wrapper -->
                            <?php
                            	$total = 0;
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php
                            	
	                            if($key == 0){
	                            	$adults = $room->room_one_adult;
	                            	$childs = $room->room_one_child;
	                            }
	                            else{
	                            	$adults = $room->room_two_adult;
	                            	$childs = $room->room_two_child;
	                            }
                            	$total += $cartData['nights']*$room->rate;
                                if($room->extra_bed_required){
                                    $total += ($room->extra_bed_rate*Session::get('nights'));
                                }
	                            
                            ?>

                            <div class="shb-booking-your-stay-item-wrapper">
                                <h3>Room <?php echo e($key+1); ?></h3>
                                <div class="sidebar_left">
                                    <ul>
                                        <li><span></span> Check in - <?php echo e(date('M d, Y',strtotime($cartData['date_from']))); ?> Check out - <?php echo e(date('M d, Y',strtotime($cartData['date_to']))); ?></li>
                                        <li><span>Guests:</span> <?php echo e($adults); ?> Adults, <?php echo e($childs); ?> Child</li>
                                    </ul>
                                </div>
                                <div class="sidebar_center">
                                    <!-- BEGIN .shb-booking-your-stay-item -->
                                    <div class="shb-booking-your-stay-item shb-clearfix">
                                        <a href="#" class="shb-booking-stay-image">
                                            <img src="<?php echo e(url('/uploads/hotels/' . $room->hotel->image)); ?>" alt="<?php echo e($room->hotel->name); ?>" />
                                        </a>
                                        <div class="shb-booking-your-stay-item-info">
                                            <h4 class="shb-clearfix"><a href="#"><?php echo e($room->hotel->name); ?></a><span> ₹<?php echo e($cartData['nights']*$room->rate); ?></span>
                                            </h4>
                                            <p class="shb-booking-your-stay-item-info-detail"><?php echo e($room->room_type); ?></p>
                                            <p class="shb-booking-price-expand"><a href="#"><?php echo e($cartData['nights']); ?> Night</a><i
                                                    class="fas fa-chevron-down"></i></p>
                                            <div class="shb-booking-price-expanded">
                                                
                                                <p class="shb-clearfix"><span> ₹<?php echo e($room->rate); ?> per night</span>
                                                </p>
                                            </div>
                                        </div>
                                        <!-- END .shb-booking-your-stay-item -->
                                    </div>
                                </div>
                                <?php
                                    $removeRoom = url('booking-summary').'?type=removeRoom&key='.$key;
                                ?>
                                <div class="sidebar_right">
                                    <a href="<?php echo e($removeRoom); ?>">Remove</a>
                                </div>
                                <?php if($room->extra_bed_available): ?>
                                
                                
                                <div class="custom_extra_bed">
                                    <!-- BEGIN .shb-additionalfee-result-wrapper -->
                                    <form class="shb-additionalfee-result-wrapper"
                                        action=""
                                        method="post" autocomplete="off">
                                        <div class="shb-additionalfee-info">
                                            <h4>Extra Bed</h4>
                                            <div class="shb-additionalfee-price">
                                                <span> ₹<?php echo e($room->extra_bed_rate); ?> | Per Night</span>
                                                <div><br>

                                                    <?php
                                                        $extraBedAdd = url('booking-summary').'?type=add&key='.$key.'&extra_bed_rate='.$room->extra_bed_rate;
                                                        $extraBedRemove = url('booking-summary').'?type=remove&key='.$key.'&extra_bed_rate='.$room->extra_bed_rate;
                                                    ?>
                                                    <?php if($room->extra_bed_required): ?>
                                                    <a href="<?php echo e($extraBedRemove); ?>" class="primary-button sm">Remove</a>
                                                    <?php else: ?>
                                                    <a href="<?php echo e($extraBedAdd); ?>" class="primary-button sm">Select</a>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="shb_accommodation_selected" value="1">
                                        <input type="hidden" name="shb_additionalfee_selected" value="1129">
                                    </form>
                                    <!-- END .shb-booking-your-stay-item -->
                                </div>
                                <?php endif; ?>
                                <!-- BEGIN .shb-booking-your-stay-controls -->
                                <div class="shb-booking-your-stay-controls shb-clearfix">
                                    <!-- END .shb-booking-your-stay-controls -->
                                </div>
                                <!-- END .shb-booking-your-stay-item-wrapper -->
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        	<?php endif; ?>
                            <!-- END .shb-booking-your-stay-items-wrapper -->
                        </div>
                        <!-- BEGIN .shb-booking-total -->
                        <div class="shb-booking-total border_bottom">
                            <h4>Total</h4>
                            <h4>₹<?php echo e($total); ?></h4>
                            <!-- END .shb-booking-total -->
                        </div>
                        <a href="javascript:void(0)" class="shb-booking-continue"
                            onclick="return shb_booking_continue()">Continue</a>
                        <!-- END .shb-booking-your-stay-wrapper -->
                    </div>
                    <!-- END .shb-booking-page-sidebar -->
                </div>


                <div class="guests_info_front_main_div">
                    <form method="POST" id="guests_info_front_form" action="<?php echo e(url('booking-summary')); ?>" autocomplete="off">
                        <?php echo csrf_field(); ?>
                        <?php $__empty_1 = true; $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                        <input type="hidden" name="rooms[<?php echo e($key); ?>][data]" value="<?php echo e(json_encode($room)); ?> ">

                        <div class="guestInformation">
	                        <h3>Room <?php echo e($key+1); ?></h3>
	                        <h5>Guests</h5>

	                        <?php
	                            if($key == 0){
	                            	$adults = $room->room_one_adult;
	                            	$childs = $room->room_one_child;
	                            }
	                            else{
	                            	$adults = $room->room_two_adult;
	                            	$childs = $room->room_two_child;
	                            }
                            ?>


	                        <?php for($i = 0; $i < $adults ; $i++): ?>
	                        	<p>Adults <?php echo e($i+1); ?></p>
	                        	<div class="Guests_info_front_box">
		                            <select required name="rooms[<?php echo e($key); ?>][title][<?php echo e($i); ?>]">
		                                <option value="Mr">Mr.</option>
		                                <option value="Miss">Miss</option>
		                                <option value="Mrs">Mrs.</option>
		                            </select>
		                            <div class="form-item">
		                                <input type="text" maxlength="25" required name="rooms[<?php echo e($key); ?>][first_name][<?php echo e($i); ?>]"
		                                    value="" placeholder="First Name">
		                            </div>
		                            <div class="form-item">
		                                <input type="text" maxlength="25" required name="rooms[<?php echo e($key); ?>][last_name][<?php echo e($i); ?>]"
		                                    value="" placeholder="Last Name">
		                            </div>
		                        </div>
	                        <?php endfor; ?>

	                        <?php if($childs > 0): ?>
	                        	<h5>Children</h5>
	                        <?php endif; ?>
	                        <?php for($i = 0; $i < $childs ; $i++): ?>
	                        <p>Children <?php echo e($i+1); ?></p>
	                        <div class="Guests_info_front_box">
	                            <select required name="rooms[<?php echo e($key); ?>][child_title][<?php echo e($i); ?>]">
	                                <!--<option value="">Select Title</option> -->
	                                <option value="Mr">Mr.</option>
	                                <option value="Miss">Miss</option>
	                                <option value="Mrs">Mrs.</option>
	                            </select>
	                            <div class="form-item">
	                                <input type="text" maxlength="25" required
	                                    name="rooms[<?php echo e($key); ?>][child_first_name][<?php echo e($i); ?>]" value=""
	                                    placeholder="First Name" />
	                            </div>
	                            <div class="form-item">
	                                <input type="text" maxlength="25" required
	                                    name="rooms[<?php echo e($key); ?>][child_last_name][<?php echo e($i); ?>]" value=""
	                                    placeholder="Last Name" />
	                            </div>
	                        </div>
	                        <?php endfor; ?>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <?php endif; ?>


                        <p>
                            <label>Special Request</label>
                            <textarea maxlength="200" rows="1" name="special_request"></textarea>
                        </p>
                        <p>
                            <input type="checkbox"
                                data-mess=" Please accept the terms and conditions to proceed further with the booking process."
                                name="agree_on" required /> I Agree on <a target="_blank" href="about-us/">About Us</a> |
                            <a target="_blank" href="privacy-policy/">Privacy Policy</a> | <a target="_blank"
                                href="booking-policy/">Booking Policy</a> | <a target="_blank"
                                href="terms-and-conditions/">Terms and conditions</a> | <a target="_blank"
                                href="refund-cancellation-policy/">Refund &amp; Cancellation Policy</a>
                        </p>
                        <br>
                        <div class="sav_next">
                            <input type="submit" value="Save and Next" class="primary-button md" />
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Frontend\Resources/views/bookingSummary.blade.php ENDPATH**/ ?>