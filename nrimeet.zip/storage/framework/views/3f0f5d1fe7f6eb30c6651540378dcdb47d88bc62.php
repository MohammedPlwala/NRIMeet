

<?php $__env->startSection('content'); ?>
    <div class="nk-block-head nk-block-head-sm">
        <div class="nk-block-between">
            <div class="nk-block-head-content">
                <h3 class="nk-block-title page-title"><a href="javascript:history.back()" class="pt-3"><em
                            class="icon ni ni-chevron-left back-icon"></em> </a>Edit Booking</h3>
            </div><!-- .nk-block-head-content -->
        </div><!-- .nk-block-between -->
    </div><!-- .nk-block-head -->
    <form role="form" method="post" enctype="multipart/form-data"
        action="<?php echo e(url('admin/bookings/update-booking/' . $booking->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Room <br> Information</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Guest Name','for' => 'guest','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Guest Name','for' => 'guest','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'guest','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Guest','name' => 'guest']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'guest','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Guest','name' => 'guest']); ?>
                                        <option>Select Guest</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $guests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option <?php if($booking->user_id == $guest->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($guest->id); ?>"><?php echo e(ucfirst($guest->full_name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Hotel Name','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Hotel Name','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel','name' => 'hotel']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'hotel','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Hotel','name' => 'hotel']); ?>
                                        <option>Select Hotel</option>
                                        <?php $__empty_1 = true; $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <option <?php if($booking->hotel_id == $hotel->id): ?> selected <?php endif; ?>
                                                value="<?php echo e($hotel->id); ?>"><?php echo e(ucfirst($hotel->name)); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Select check IN and Check out Date','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Select check IN and Check out Date','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(date('m/d/Y', strtotime($booking->check_in_date))).'','for' => 'checkin_date','class' => 'date-picker checkDate','icon' => 'calender-date-fill','required' => 'true','placeholder' => 'Date of birth','name' => 'checkin_date']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                        <div class="col-lg-6">
                                            <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(date('m/d/Y', strtotime($booking->check_out_date))).'','for' => 'checkout_date','class' => 'date-picker checkDate','icon' => 'calender-date-fill','required' => 'true','placeholder' => 'Date of birth','name' => 'checkout_date']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Room One <br> Guests</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <table class="table table-borderd">
                            <tr>
                                <th class="pt-3 pb-3">Room Name</th>
                                <th class="pt-3 pb-3">Adult</th>
                                <th class="pt-3 pb-3">Child</th>
                                <th class="pt-3 pb-3">Extra Bed</th>
                                <th  class="pt-3 pb-3">Extra Bed Cost</th>
                                <th class="pt-3 pb-3">Per/Night</th>
                                <th class="text-right pt-3 pb-3">Price</th>
                            </tr>
                            <tr>
                                <td>
                                    <select id="room_one_type" required="true" class="form-select roomType"
                                        name="room_one_type">
                                        <option value="">Select Room</option>
                                        <select>
                                </td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'room_one_adult','icon' => 'mail','required' => 'true','class' => '','name' => 'room_one_adult','id' => 'room_one_adult']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'room_one_adult','icon' => 'mail','required' => 'true','class' => '','name' => 'room_one_adult','id' => 'room_one_adult']); ?>
                                        <option <?php if($bookingRooms[0]['adults'] == 0): ?> selected <?php endif; ?> value="0">0</option>
                                        <option <?php if($bookingRooms[0]['adults'] == 1): ?> selected <?php endif; ?> value="1">1</option>
                                        <option <?php if($bookingRooms[0]['adults'] == 2): ?> selected <?php endif; ?> value="2">2</option>
                                        <option <?php if($bookingRooms[0]['adults'] == 3): ?> selected <?php endif; ?> value="3">3</option>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'room_one_child','icon' => 'mail','required' => 'true','class' => '','name' => 'room_one_child']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'room_one_child','icon' => 'mail','required' => 'true','class' => '','name' => 'room_one_child']); ?>

                                        <option <?php if($bookingRooms[0]['childs'] == 0): ?> selected <?php endif; ?> value="0">0</option>
                                        <option <?php if($bookingRooms[0]['childs'] == 1): ?> selected <?php endif; ?> value="1">1</option>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </td>
                                <td>
                                    <select id="room_one_extraBed" icon="mail" required="true" class="form-select"
                                        name="room_one_extraBed">

                                        <option <?php if($bookingRooms[0]['extra_bed'] == 0): ?> selected <?php endif; ?> value="0">No
                                        </option>
                                        <option <?php if($bookingRooms[0]['extra_bed'] == 1): ?> selected <?php endif; ?> value="1">Yes
                                        </option>

                                    </select>
                                </td>
                                <td>
                                    ₹<span id="room_one_extraBed_rate"></span> / Night<br />
                                    <small>Tax Inclusive</small>
                                </td>
                                <td>
                                    ₹<span id="room_one_rate"><?php echo e($bookingRooms[0]['rate']); ?></span> / Night<br />
                                    <small>Tax Inclusive</small>
                                </td>
                                <td class="text-right">
                                    <input type="hidden" id="room_one_price_input" name="room_one_price"
                                        value="<?php echo e($bookingRooms[0]['amount']); ?>">
                                    <input type="hidden" id="room_one_data" name="room_one_data">
                                    ₹<span id="room_one_price"><?php echo e($bookingRooms[0]['amount']); ?></span>
                                </td>
                            </tr>

                        </table>
                        <div class="sp-plan-info card-inner pt-0">
                            <div id="cont_room_one_adult"></div>
                            <div id="cont_room_one_child"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Room Two <br> Guests</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <table class="table table-borderd">
                            <tr>
                                <th class="pt-3 pb-3">Room Name</th>
                                <th class="pt-3 pb-3">Adult</th>
                                <th class="pt-3 pb-3">Child</th>
                                <th class="pt-3 pb-3">Extra Bed</th>
                                <th class="pt-3 pb-3">Extra Bed Cost</th>
                                <th class="pt-3 pb-3">Per/Night</th>
                                <th class="text-right pt-3 pb-3">Price</th>
                            </tr>
                            <tr>
                                <td>
                                    <select class="form-select roomType" id="room_two_type" placeholder="Select Type"
                                        name="room_two_type">
                                        <option value="">Select Room</option>
                                    </select>
                                </td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'room_two_adult','icon' => 'mail','required' => 'true','class' => '','name' => 'room_two_adult']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'room_two_adult','icon' => 'mail','required' => 'true','class' => '','name' => 'room_two_adult']); ?>

                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['adults'] == 0): ?> selected <?php endif; ?> value="0">0
                                        </option>
                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['adults'] == 1): ?> selected <?php endif; ?> value="1">1
                                        </option>
                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['adults'] == 2): ?> selected <?php endif; ?> value="2">2
                                        </option>
                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['adults'] == 3): ?> selected <?php endif; ?> value="3">3
                                        </option>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </td>
                                <td>
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'room_two_child','icon' => 'mail','required' => 'true','class' => '','name' => 'room_two_child']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'room_two_child','icon' => 'mail','required' => 'true','class' => '','name' => 'room_two_child']); ?>

                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['childs'] == 0): ?> selected <?php endif; ?> value="0">0
                                        </option>
                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['childs'] == 1): ?> selected <?php endif; ?> value="1">1
                                        </option>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </td>
                                <td>
                                    <select id="room_two_extraBed" icon="mail" required="true" class="form-select"
                                        name="room_two_extraBed">

                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['extra_bed'] == 0): ?> selected <?php endif; ?> value="0">No
                                        </option>
                                        <option <?php if(isset($bookingRooms[1]) && $bookingRooms[1]['extra_bed'] == 1): ?> selected <?php endif; ?> value="1">Yes
                                        </option>

                                    </select>
                                </td>
                                <td>
                                    ₹<span id="room_two_extraBed_rate"></span> / Night<br />
                                    <small>Tax Inclusive</small>
                                </td>

                                <td>
                                    ₹<span
                                        id="room_two_rate"><?php echo e(isset($bookingRooms[1]) ? $bookingRooms[1]['rate'] : 0); ?></span>
                                    / Night<br />
                                    <small>Tax Inclusive</small>

                                </td>
                                <td class="text-right">
                                    <input type="hidden" id="room_two_price_input" name="room_two_price"
                                        value="<?php echo e(isset($bookingRooms[1]) ? $bookingRooms[1]['amount'] : 0); ?>">
                                    <input type="hidden" id="room_two_data" name="room_two_data">
                                    ₹<span
                                        id="room_two_price"><?php echo e(isset($bookingRooms[1]) ? $bookingRooms[1]['amount'] : 0); ?></span>
                                </td>
                            </tr>
                        </table>
                        <div class="sp-plan-info card-inner pt-0">
                            <div id="cont_room_two_adult"></div>
                            <div id="cont_room_two_child"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Special <br> Request</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Special Request Details','for' => 'special_request','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Special Request Details','for' => 'special_request','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.textarea','data' => ['value' => ''.e(isset($booking) ? $booking->special_request : '').'','for' => 'special_request','class' => '','icon' => 'notes-alt','name' => 'special_request']]); ?>
<?php $component->withName('inputs.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['value' => ''.e(isset($booking) ? $booking->special_request : '').'','for' => 'special_request','class' => '','icon' => 'notes-alt','name' => 'special_request']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <div class="nk-block">
            <div class="card card-bordered sp-plan">
                <div class="row no-gutters">
                    <div class="col-md-3">
                        <div class="sp-plan-action card-inner">
                            <div class="icon">
                                <em class="icon ni ni-box fs-36px o-5"></em>
                                <h5 class="o-5">Confirmation & <br> Settlement</h5>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-9">
                        <div class="sp-plan-info card-inner">
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Status','for' => 'hotel','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Status','for' => 'hotel','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.select','data' => ['for' => 'status','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Status','name' => 'status']]); ?>
<?php $component->withName('inputs.select'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['for' => 'status','icon' => 'mail','required' => 'true','class' => '','placeholder' => 'Select Status','name' => 'status']); ?>
                                        <option <?php if($booking->booking_status == 'Booking Received'): ?> selected <?php endif; ?>
                                            value="Booking Received">Booking Received</option>
                                        <option <?php if($booking->booking_status == 'Payment Completed'): ?> selected <?php endif; ?>
                                            value="Payment Completed">Payment Completed</option>
                                        <option <?php if($booking->booking_status == 'Booking Shared'): ?> selected <?php endif; ?> value="Booking Shared">
                                            Booking Shared</option>
                                        <option <?php if($booking->booking_status == 'Confirmation Recevied'): ?> selected <?php endif; ?>
                                            value="Confirmation Recevied">Confirmation Recevied</option>
                                        <option <?php if($booking->booking_status == 'Cancellation Requested'): ?> selected <?php endif; ?>
                                            value="Cancellation Requested">Cancellation Requested</option>
                                        <option <?php if($booking->booking_status == 'Cancellation Approved'): ?> selected <?php endif; ?>
                                            value="Cancellation Approved">Cancellation Approved</option>
                                        <option <?php if($booking->booking_status == 'Refund Requested'): ?> selected <?php endif; ?>
                                            value="Refund Requested">Refund Requested</option>
                                        <option <?php if($booking->booking_status == 'Refund Approved'): ?> selected <?php endif; ?>
                                            value="Refund Approved">Refund Approved</option>
                                        <option <?php if($booking->booking_status == 'Refund Issued'): ?> selected <?php endif; ?> value="Refund Issued">
                                            Refund Issued</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Confirmation Number','for' => 'confirmation_number','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Confirmation Number','for' => 'confirmation_number','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(isset($booking) ? $booking->confirmation_number : '').'','for' => 'confirmation_number','class' => '','icon' => 'building-fill','name' => 'confirmation_number']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'UTR Number','for' => 'utr_number','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'UTR Number','for' => 'utr_number','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(isset($booking) ? $booking->utr_number : '').'','for' => 'utr_number','class' => '','icon' => 'building-fill','name' => 'utr_number']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                </div>
                            </div>

                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => 'Settlement Date','for' => 'settlement_date','suggestion' => '']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => 'Settlement Date','for' => 'settlement_date','suggestion' => '']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => ''.e(isset($booking) ? $booking->settlement_date : '').'','for' => 'settlement_date','class' => 'date-picker','icon' => 'building-fill','name' => 'settlement_date']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- .nk-block -->

        <div class="nk-block">
            <?php if(isset($user)): ?>
                <input type="hidden" name="userId" id="userId" value="<?php echo e($user->id); ?>">
            <?php endif; ?>
            <div class="row">
                <div class="col-md-12">
                    <div class="sp-plan-info pt-0 pb-0 card-inner">
                        <div class="row">
                            <div class="col-lg-7 text-right offset-lg-5">
                                <div class="form-group">
                                    <a href="javascript:history.back()" class="btn btn-outline-light">Cancel</a>
                                    <?php if (isset($component)) { $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Button::class, []); ?>
<?php $component->withName('button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'btn btn-primary']); ?>Submit <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940)): ?>
<?php $component = $__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940; ?>
<?php unset($__componentOriginal065ae5da12ba8e75c6b4e84d90798c2fb812b940); ?>
<?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div><!-- .sp-plan-info -->
                </div><!-- .col -->
            </div><!-- .row -->
        </div>
    </form>

    <input type="hidden" name="role_type" id="role_type" value="<?php echo e(\Config::get('constants.ROLES.BUYER')); ?>">
    <input type="hidden" name="old_district" id="old_district" value="<?php echo e(old('district')); ?>">
    <input type="hidden" name="old_city" id="old_city" value="<?php echo e(old('city')); ?>">

    <script type="text/javascript">
        $(document).ready(function() {


            $('#room_one_type').change(function() {
                if ($(this).val() != "") {
                    var roomData = $('option:selected', this).attr('data-roomdata');
                    $('#room_one_data').val(roomData);
                    roomData = JSON.parse(roomData);

                    if (roomData.extra_bed_available) {
                        $('#room_one_extraBed').prop('disabled', false);
                    } else {
                        $('#room_one_extraBed').prop('disabled', true);
                    }
                    var rate = parseFloat(roomData.rate);
                    rate = rate.toFixed(2);
                    $('#room_one_rate').text(rate);

                    var nights = getNights();
                    var price = (parseFloat(roomData.rate) * nights);
                    $('#room_one_price').text(price.toFixed(2));
                    $('#room_one_price_input').val(price.toFixed(2));
                }

            });

            $('#room_one_extraBed').change(function() {
                if ($(this).val() != "") {
                    var roomData = $('option:selected', '#room_one_type').attr('data-roomdata');
                    roomData = JSON.parse(roomData);
                    var price = 0;

                    var nights = getNights();

                    if ($(this).val() == 1) {

                        $('#room_one_extraBed_rate').text(roomData.extra_bed_rate);
                        price = ((parseFloat(roomData.rate) * nights) + (parseFloat(roomData.extra_bed_rate) * nights));
                    } else {
                        $('#room_one_extraBed_rate').text(0);
                        price = (parseFloat(roomData.rate) * nights);
                    }
                    $('#room_one_price').text(price.toFixed(2));
                    $('#room_one_price_input').val(price.toFixed(2));
                }

            });

            $('#room_two_type').change(function() {
                if ($(this).val() != "") {
                    var roomData = $('option:selected', this).attr('data-roomdata');
                    $('#room_two_data').val(roomData);
                    roomData = JSON.parse(roomData);

                    if (roomData.extra_bed_available) {
                        $('#room_two_extraBed').prop('disabled', false);
                    } else {
                        $('#room_two_extraBed').prop('disabled', true);
                    }
                    var rate = parseFloat(roomData.rate);
                    rate = rate.toFixed(2);
                    $('#room_two_rate').text(rate);

                    var nights = getNights();
                    var price = (parseFloat(roomData.rate) * nights);
                    $('#room_two_price').text(price.toFixed(2));
                    $('#room_two_price_input').val(price.toFixed(2));
                }

            });

            $('#room_two_extraBed').change(function() {
                if ($(this).val() != "") {
                    var roomData = $('option:selected', '#room_two_type').attr('data-roomdata');
                    roomData = JSON.parse(roomData);
                    var price = 0;

                    var nights = getNights();

                    if ($(this).val() == 1) {
                        $('#room_two_extraBed_rate').text(roomData.extra_bed_rate);
                        price = ((parseFloat(roomData.rate) * nights) + (parseFloat(roomData.extra_bed_rate) * nights));
                    } else {
                        $('#room_two_extraBed_rate').text(0);
                        price = (parseFloat(roomData.rate) * nights);
                    }
                    $('#room_two_price').text(price.toFixed(2));
                    $('#room_two_price_input').val(price.toFixed(2));
                }

            });

            function getNights() {
                var nights = 0;
                var checkin_date = $('#checkin_date').val();
                var checkout_date = $('#checkout_date').val();

                if (checkin_date != "" && checkout_date != "") {
                    var diffInMs = new Date(checkout_date) - new Date(checkin_date)
                    nights = diffInMs / (1000 * 60 * 60 * 24);
                }

                return nights;
            }

            $('.checkDate').change(function() {
                var nights = getNights();
                $('#room_one_type').trigger('change');
                $('#room_two_type').trigger('change');
            });


            $('#hotel').change(function() {
                var root_url = "<?php echo Request::root(); ?>";
                $.ajax({
                    url: root_url + '/admin/hotel/hotel-rooms/' + $(this).val(),
                    data: {

                    },
                    //dataType: "html",
                    method: "GET",
                    cache: false,
                    success: function(response) {
                        if (response.success) {
                            $('#room_one_price').text('');
                            $('#room_one_price_input').val('');
                            $('#room_two_price').text('');
                            $('#room_two_price_input').val('');
                            // $('#room_one_extraBed').val(0).trigger('change');
                            // $('#room_two_extraBed').val(0).trigger('change');


                            $('.roomType')
                                .find('option')
                                .remove()
                                .end()
                                .append('<option value="">Select Room</option>');

                            $.each(response.hotelRooms, function(key, room) {
                                $('.roomType')
                                    .append($("<option></option>")
                                        .attr("value", room.id)
                                        .attr("data-roomData", JSON.stringify(room))
                                        .text(room.room_type_name));
                            });

                            <?php if(isset($bookingRooms[0])): ?>
                                var roomValue = "<?php echo $bookingRooms[0]['room_id']; ?>";
                                $("#room_one_type").val(parseInt(roomValue));
                                $('#room_one_type').trigger('change');
                                $('#room_one_adult').trigger('change');
                                $('#room_one_child').trigger('change');
                                $('#room_one_extraBed').trigger('change');
                            <?php endif; ?>

                            <?php if(isset($bookingRooms[1])): ?>
                                var roomValue = "<?php echo $bookingRooms[1]['room_id']; ?>";
                                $("#room_two_type").val(parseInt(roomValue));
                                $('#room_two_type').trigger('change');

                                $('#room_two_adult').trigger('change');
                                $('#room_two_child').trigger('change');
                                $('#room_two_extraBed').trigger('change');
                            <?php endif; ?>

                        }
                    }
                });
            });

            $('#hotel').trigger('change');

            function addRoomDetails(container, value, room, isChild = false) {
                $(container).html('')
                var html = ''
                var label = isChild ? 'Children' : 'Adults'
                var title = isChild ? 'child_title' : 'title'
                var firstName = isChild ? 'child_first_name' : 'first_name'
                var firstLast = isChild ? 'child_last_name' : 'last_name'

                for (let index = 0; index < value; index++) {
                    html += `
                            <div class="row g-3 align-center">
                                <div class="col-lg-4">
                                    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.inputs.verticalFormLabel','data' => ['label' => '${label} ${index + 1}','for' => 'adults_one_title','suggestion' => '','required' => 'true']]); ?>
<?php $component->withName('inputs.verticalFormLabel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['label' => '${label} ${index + 1}','for' => 'adults_one_title','suggestion' => '','required' => 'true']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-8">
                                    <?php if (isset($component)) { $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Inputs\Text::class, ['value' => '','for' => 'rooms_${room}_${firstName}_${index}','name' => 'rooms[${room}][${firstName}][${index}]','placeholder' => 'Full Name']); ?>
<?php $component->withName('inputs.text'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd)): ?>
<?php $component = $__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd; ?>
<?php unset($__componentOriginal942cbedc8524995abeccadc00a91f89c8cb356bd); ?>
<?php endif; ?>
                                </div>
                            </div>
                        `
                }
                $(container).append(html)
            }


            $("#room_one_adult").on("change", function() {
                var value = $(this).val()
                addRoomDetails('#cont_room_one_adult', value, 0)
            });

            $("#room_one_child").on("change", function() {
                var value = $(this).val()
                addRoomDetails('#cont_room_one_child', value, 0, true)
            });

            $("#room_two_adult").on("change", function() {
                var value = $(this).val()
                addRoomDetails('#cont_room_two_adult', value, 1)
            });

            $("#room_two_child").on("change", function() {
                var value = $(this).val()
                addRoomDetails('#cont_room_two_child', value, 1, true)
            });


            console.log('room_one_data', room_one_data);
            console.log('room_two_data', room_two_data);

            <?php if(isset($bookingRooms[0])): ?>
                var room_one_data = JSON.parse('<?php echo json_encode($bookingRooms[0]); ?>');
                setTimeout(function() {
                    $('#rooms_0_first_name_0').val(room_one_data.guest_one_name);
                    $('#rooms_0_first_name_1').val(room_one_data.guest_two_name);
                    $('#rooms_0_first_name_2').val(room_one_data.guest_three_name);
                    $('#rooms_0_child_first_name_0').val(room_one_data.child_name);
                }, 2000);
            <?php endif; ?>

            <?php if(isset($bookingRooms[1])): ?>
                var room_two_data = JSON.parse('<?php echo json_encode($bookingRooms[1]); ?>');
                setTimeout(function() {
                    var room_one_data = JSON.parse('<?php echo json_encode($bookingRooms[0]); ?>');
                    $('#rooms_1_first_name_0').val(room_two_data.guest_one_name);
                    $('#rooms_1_first_name_1').val(room_two_data.guest_two_name);
                    $('#rooms_1_first_name_2').val(room_two_data.guest_three_name);
                    $('#rooms_1_child_first_name_0').val(room_two_data.child_name);
                }, 2000);
            <?php endif; ?>


        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Hotel\Resources/views/editBooking.blade.php ENDPATH**/ ?>