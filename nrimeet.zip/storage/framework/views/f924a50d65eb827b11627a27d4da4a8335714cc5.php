<?php $attributes = $attributes->exceptProps([
    'for'=> '',
    'label' => '',
    'suggestion' => '',
    'required' => 'false'
]); ?>
<?php foreach (array_filter(([
    'for'=> '',
    'label' => '',
    'suggestion' => '',
    'required' => 'false'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group">
    <label class="form-label" for="<?php echo e($for); ?>"><?php echo e($label); ?><?php if($required != 'false'): ?><span class="text-danger">*</span><?php endif; ?></label>
    <span class="form-note"><?php echo e($suggestion); ?></span>
</div><?php /**PATH C:\xampp\htdocs\nrimeet\resources\views/components/inputs/verticalFormLabel.blade.php ENDPATH**/ ?>