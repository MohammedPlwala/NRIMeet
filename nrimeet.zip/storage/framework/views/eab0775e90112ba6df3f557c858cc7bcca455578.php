

<?php $__env->startSection('content'); ?>
  <!-- Page Header -->
  <div class="page-header">
	<h1>My Bookings</h1>
  </div>
 <div class="container">

 	

	<div class="my-bookings-section">
 		<?php $__empty_1 = true; $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
	  	<div class="shb-booking-summary-wrapper">
			<div class="shb-booking-summary-item">
				<h4><?php echo e($booking->hotel_name); ?> </h4> <a href="<?php echo e(url('booking-invoice/'.$booking->id)); ?>">Download Invoice</a>
				<ul>
				  	<li><strong>Dates:</strong> <?php echo e(date('d M, Y',strtotime($booking->check_in_date))); ?> - <?php echo e(date('d M, Y',strtotime($booking->check_out_date))); ?> (<?php echo e($booking->nights); ?> Night)</li>
				  	<li><strong>Guests:</strong> <?php echo e($booking->adults); ?> Adult, <?php echo e($booking->childs); ?> Children</li>
				</ul>
				<?php $__empty_2 = true; $__currentLoopData = $booking->rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rkey => $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
				<div class="shb-booking-summary-item-inner">
			  		<h5>Room <?php echo e($rkey+1); ?> </h5>
			  		<ul>
					  	<li><strong>Type:</strong> <?php echo e($room->name); ?></li>
					  	<li><strong>Rate:</strong> ₹<?php echo e($room->rate); ?>/Night</li>
					  	<?php if($room->extra_bed): ?>
					  	<li><strong>Extra Bed Rate:</strong> ₹<?php echo e($room->extra_bed_cost); ?></li></li>
					  	<?php endif; ?>
					  	<li><strong>Amount:</strong> ₹<?php echo e($room->amount); ?></li>
					  	<li><strong>Guests:</strong> <?php echo e($booking->adults); ?> Adult, <?php echo e($booking->childs); ?> Children</li>
					</ul>
			  		<div class="my_account_guest_box">
						<h5>Guests Infomation</h5>
						<div class="my_account_guest_inner">
							<p class="main_title_plural">Guests</p>
							<p class="child_title_plural">Adults 1 = <?php echo e($room->guest_one_name); ?></p>
							<?php if(!empty($room->guest_two_name)): ?>
								<p class="child_title_plural">Adults 2 = <?php echo e($room->guest_two_name); ?></p>
							<?php endif; ?>
							<?php if(!empty($room->guest_three_name)): ?>
								<p class="child_title_plural">Adults 3 = <?php echo e($room->guest_three_name); ?></p>
							<?php endif; ?>
							<?php if(!empty($room->child_name)): ?>
								<p class="child_title_plural">Child 1 = <?php echo e($room->child_name); ?></p>
							<?php endif; ?>
						</div>
			  		</div>
				</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
			  	<?php endif; ?>
			</div>
			<div class="shb-booking-summary-item amount_tax">
				<p><strong>Base Price: </strong> ₹<?php echo e($booking->sub_total); ?></p>
				<p><strong>TAX (18%): </strong> ₹<?php echo e($booking->tax); ?></p>
				<p><strong>Total: </strong> ₹<?php echo e($booking->amount); ?></p>
			</div>
	  	</div>
	  	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
	  	<h5>No Bookings</h5>
 		<?php endif; ?>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\Modules/Frontend\Resources/views/myBookings.blade.php ENDPATH**/ ?>