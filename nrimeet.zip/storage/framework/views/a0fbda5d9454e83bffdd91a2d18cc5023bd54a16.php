
<style type="text/css">
	.timeline-date{width: 200px !important;}
</style>
<?php $__env->startSection('content'); ?>
<div class="nk-content-inner">
	<div class="nk-content-body">
        <h4 style="text-align: center;">You do not have permission to access this resource.</h4>
	</div>
</div>
<!-- Mopdal Small -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\nrimeet\resources\views/error/403.blade.php ENDPATH**/ ?>