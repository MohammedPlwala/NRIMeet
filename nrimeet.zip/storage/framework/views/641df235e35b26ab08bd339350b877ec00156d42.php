<?php $attributes = $attributes->exceptProps([
    'for'=> '',
    'label' => '',
    'value'=> '',
    'placeholder'=> '',
    'id'=> '',
    'name' => '',
    'icon'=>'',
    'formNote' => '',
    'required' =>'false',
    'minlength'=>'8',
    'maxlength'=>'16',
    'autocomplete'=>'',
    'class' =>'',
    'readonly' => ''
]); ?>
<?php foreach (array_filter(([
    'for'=> '',
    'label' => '',
    'value'=> '',
    'placeholder'=> '',
    'id'=> '',
    'name' => '',
    'icon'=>'',
    'formNote' => '',
    'required' =>'false',
    'minlength'=>'8',
    'maxlength'=>'16',
    'autocomplete'=>'',
    'class' =>'',
    'readonly' => ''
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>
<div class="form-group">
    <?php if(isset($label) && $label != ''): ?>
        <label class="form-label" for="<?php echo e($for); ?>"><?php echo e($label); ?><?php if($required != ''): ?><span class="text-danger">*</span><?php endif; ?></label>
    <?php endif; ?>
    <div class="form-control-wrap">
        <?php if($icon != ''): ?>
            <div class="form-icon form-icon-left "><em class="icon ni ni-<?php echo e($icon); ?>"></em></div>
        <?php endif; ?>

        <?php if(!isset($class)): ?>
            <?php
                $class = '';
            ?>
        <?php endif; ?>

        <?php if(!isset($required)): ?>
            <?php
                $required = 'false';
            ?>
        <?php endif; ?>
        
        <input type="password" <?php if($required !='' && $required=='true' ): ?> required="<?php echo e($required); ?>" <?php endif; ?> data-parsley-errors-container=".parsley-container-<?php echo e($name); ?>" id="<?php echo e($for); ?>" value="<?php echo e($value); ?>"  name="<?php echo e($name); ?>" minlength="<?php echo e($minlength); ?>" maxlength="<?php echo e($maxlength); ?>" <?php echo e($attributes); ?> <?php echo e($attributes->merge(['class' => 'form-control ' . $class])); ?> />
    </div>

    <?php if(isset($formNote) && $formNote != ''): ?>
        <span class="form-note mt-0"><?php echo e($formNote); ?></span>
    <?php endif; ?>    

    <?php if(isset($required) && $required != 'false'): ?>
        <div class="parsley-container-<?php echo e($name); ?>"></div>
    <?php endif; ?>
</div><?php /**PATH C:\xampp\htdocs\nrimeet\resources\views/components/inputs/password.blade.php ENDPATH**/ ?>