<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Hotel\\Providers\\HotelServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Hotel\\Providers\\HotelServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);