<?php
namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Role extends Model
{
	protected $table = 'roles';
}