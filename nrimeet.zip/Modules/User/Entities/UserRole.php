<?php
namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class UserRole extends Model
{
	protected $table = 'user_role';
}