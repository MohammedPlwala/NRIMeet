<?php
namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Visit extends Model
{
	protected $table = 'darshan_registration';
}