<?php
namespace Modules\User\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class CustomerCare extends Model
{
	protected $table = 'customer_care';
    
}