<?php
namespace Modules\Hotel\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class Hotel extends Model
{
    protected $table = 'hotels';
}