<?php
namespace Modules\Hotel\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class BulkBookingRoom extends Model
{
    protected $table = 'bulk_booking_rooms';
}