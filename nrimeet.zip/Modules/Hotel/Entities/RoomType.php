<?php
namespace Modules\Hotel\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class RoomType extends Model
{
    protected $table = 'room_types';
}