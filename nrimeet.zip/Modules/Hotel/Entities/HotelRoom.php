<?php
namespace Modules\Hotel\Entities;

use Illuminate\Database\Eloquent\Model;
use Auth;

class HotelRoom extends Model
{
    protected $table = 'hotel_rooms';
}