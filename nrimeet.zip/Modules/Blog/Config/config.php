<?php

return [
    'name' => 'Blog'
];
