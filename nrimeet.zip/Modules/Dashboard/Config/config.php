<?php

return [
    'name' => 'Dashboard'
];
