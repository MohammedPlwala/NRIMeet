<?php

return [
	'page'=>[
	    'previous' => '&laquo; Previous',
	    'next' => 'Next &raquo;',
	]
];
